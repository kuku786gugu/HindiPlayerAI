from __future__ import annotations
import os, uuid
from pathlib import Path
from fastapi import FastAPI, UploadFile, File, Form, HTTPException, BackgroundTasks
from fastapi.responses import FileResponse
from pydantic import BaseModel

APP_DIR = Path(os.getenv("HPAI_DATA_DIR", "./data")).resolve()
UPLOAD_DIR = APP_DIR / "uploads"
JOB_DIR = APP_DIR / "jobs"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
JOB_DIR.mkdir(parents=True, exist_ok=True)
MAX_UPLOAD_BYTES = int(os.getenv("HPAI_MAX_UPLOAD_BYTES", str(100 * 1024**3)))
app = FastAPI(title="Hindi Player AI API", version="0.4.0")
JOBS: dict[str, dict] = {}

class JobStatus(BaseModel):
    job_id: str
    status: str
    message: str
    target_language: str
    mode: str

@app.get("/health")
def health():
    return {"ok": True, "service": "Hindi Player AI", "version": "0.4.0",
            "asr": "faster-whisper (download model on first run)",
            "translation_configured": bool(os.getenv("HPAI_TRANSLATION_URL")),
            "elevenlabs_configured": bool(os.getenv("ELEVENLABS_API_KEY")),
            "openai_tts_configured": bool(os.getenv("OPENAI_API_KEY")),
            "ffmpeg_available": os.system("ffmpeg -version >/dev/null 2>&1") == 0}

async def save_upload_stream(upload: UploadFile, destination: Path) -> int:
    total = 0
    with destination.open("wb") as out:
        while chunk := await upload.read(8 * 1024 * 1024):
            total += len(chunk)
            if total > MAX_UPLOAD_BYTES:
                destination.unlink(missing_ok=True)
                raise HTTPException(413, f"Upload exceeds configured server limit ({MAX_UPLOAD_BYTES} bytes)")
            out.write(chunk)
    return total

def run_job(job_id: str):
    from pipeline import process_online
    job = JOBS[job_id]
    def update(state, message):
        job["status"] = state
        job["message"] = message
    try:
        if job["mode"] == "offline":
            raise RuntimeError("Offline AI model runtime/voice weights are not installed. Use online mode until licensed offline models are packaged and tested.")
        audio = process_online(job, update)
        job["audio_path"] = str(audio)
    except Exception as exc:
        job["status"] = "failed"
        job["message"] = str(exc)

@app.post("/jobs", response_model=JobStatus)
async def create_job(background: BackgroundTasks,
                     movie: UploadFile = File(...),
                     target_language: str = Form("Hindi"),
                     mode: str = Form("online"),
                     provider: str = Form("elevenlabs"),
                     voice_id: str = Form("")):
    if mode not in {"online", "offline"}:
        raise HTTPException(400, "mode must be online or offline")
    if provider not in {"elevenlabs", "openai"}:
        raise HTTPException(400, "provider must be elevenlabs or openai")
    job_id = uuid.uuid4().hex
    suffix = Path(movie.filename or "movie.bin").suffix[:12]
    path = UPLOAD_DIR / f"{job_id}{suffix}"
    size = await save_upload_stream(movie, path)
    job_dir = JOB_DIR / job_id
    JOBS[job_id] = {"job_id": job_id, "status": "queued", "message": "Upload received.",
                    "target_language": target_language, "mode": mode, "provider": provider,
                    "voice_id": voice_id, "path": str(path), "job_dir": str(job_dir), "size_bytes": size}
    background.add_task(run_job, job_id)
    return JobStatus(job_id=job_id, status="queued", message="Movie uploaded; AI processing queued.", target_language=target_language, mode=mode)

@app.get("/jobs/{job_id}")
def get_job(job_id: str):
    job = JOBS.get(job_id)
    if not job:
        raise HTTPException(404, "job not found")
    return {k: v for k, v in job.items() if k not in {"path", "job_dir"}}

@app.get("/jobs/{job_id}/audio")
def get_audio(job_id: str):
    job = JOBS.get(job_id)
    if not job:
        raise HTTPException(404, "job not found")
    audio = job.get("audio_path")
    if not audio or not Path(audio).exists():
        raise HTTPException(409, "dubbed audio is not ready")
    return FileResponse(audio, media_type="audio/mpeg", filename="hindi-dubbed-track.mp3")
