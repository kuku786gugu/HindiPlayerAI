"""Online dubbing worker: FFmpeg -> faster-whisper -> LibreTranslate -> ElevenLabs.

Requires configured server-side credentials and FFmpeg. This is a first online
pipeline, not studio-grade multi-speaker diarization or source separation.
"""
from __future__ import annotations
import os, subprocess, tempfile, json
from pathlib import Path
import httpx
from faster_whisper import WhisperModel
from pydub import AudioSegment

LANG_CODES = {
    "Hindi": "hi", "Bhojpuri": "hi", "Bengali": "bn", "Tamil": "ta",
    "Telugu": "te", "Marathi": "mr", "Punjabi": "pa", "Gujarati": "gu",
    "Kannada": "kn", "Malayalam": "ml", "Odia": "or", "Assamese": "as",
}


def run_ffmpeg(args: list[str]):
    p = subprocess.run(["ffmpeg", "-y", *args], capture_output=True, text=True)
    if p.returncode:
        raise RuntimeError("FFmpeg failed: " + p.stderr[-2500:])


def translate_text(text: str, target_code: str) -> str:
    url = os.getenv("HPAI_TRANSLATION_URL", "").rstrip("/")
    if not url:
        raise RuntimeError("Set HPAI_TRANSLATION_URL to a LibreTranslate-compatible /translate endpoint")
    payload = {"q": text, "source": "auto", "target": target_code, "format": "text"}
    key = os.getenv("HPAI_TRANSLATION_API_KEY")
    if key:
        payload["api_key"] = key
    with httpx.Client(timeout=90) as client:
        r = client.post(url, json=payload)
        r.raise_for_status()
        result = r.json().get("translatedText")
        if not result:
            raise RuntimeError("Translation provider returned no translatedText")
        return result


def synthesize_elevenlabs(text: str, voice_id: str, output: Path):
    api_key = os.getenv("ELEVENLABS_API_KEY", "")
    if not api_key:
        raise RuntimeError("Set ELEVENLABS_API_KEY on the backend")
    if not voice_id:
        voice_id = os.getenv("ELEVENLABS_DEFAULT_VOICE_ID", "")
    if not voice_id:
        raise RuntimeError("Set ELEVENLABS_DEFAULT_VOICE_ID or submit voice_id")
    url = f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}"
    headers = {"xi-api-key": api_key, "accept": "audio/mpeg", "content-type": "application/json"}
    body = {"text": text, "model_id": os.getenv("ELEVENLABS_MODEL_ID", "eleven_multilingual_v2"),
            "voice_settings": {"stability": 0.55, "similarity_boost": 0.75}}
    with httpx.Client(timeout=180) as client:
        with client.stream("POST", url, headers=headers, json=body) as r:
            r.raise_for_status()
            with output.open("wb") as f:
                for chunk in r.iter_bytes():
                    f.write(chunk)



def synthesize_openai(text: str, output: Path):
    """OpenAI speech endpoint; configure key/model/voice server-side."""
    api_key = os.getenv("OPENAI_API_KEY", "")
    if not api_key:
        raise RuntimeError("Set OPENAI_API_KEY on the backend to use the OpenAI TTS provider")
    url = os.getenv("OPENAI_TTS_URL", "https://api.openai.com/v1/audio/speech")
    body = {"model": os.getenv("OPENAI_TTS_MODEL", "tts-1"),
            "voice": os.getenv("OPENAI_TTS_VOICE", "alloy"),
            "input": text, "response_format": "mp3"}
    headers = {"Authorization": f"Bearer {api_key}", "content-type": "application/json"}
    with httpx.Client(timeout=180) as client:
        with client.stream("POST", url, headers=headers, json=body) as r:
            r.raise_for_status()
            with output.open("wb") as f:
                for chunk in r.iter_bytes():
                    f.write(chunk)


def synthesize(text: str, job: dict, output: Path):
    provider = (job.get("provider") or "elevenlabs").lower()
    if provider == "openai":
        synthesize_openai(text, output)
    elif provider == "elevenlabs":
        synthesize_elevenlabs(text, job.get("voice_id", ""), output)
    else:
        raise RuntimeError(f"Unsupported TTS provider: {provider}")

def process_online(job: dict, update):
    movie = Path(job["path"])
    job_dir = Path(job["job_dir"])
    job_dir.mkdir(parents=True, exist_ok=True)
    audio_wav = job_dir / "source.wav"
    dubbed_mp3 = job_dir / "dubbed-track.mp3"
    update("extracting_audio", "Movie se audio extract ho raha hai...")
    run_ffmpeg(["-i", str(movie), "-vn", "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le", str(audio_wav)])

    update("transcribing", "AI original dialogue aur timestamps pehchan raha hai...")
    model_name = os.getenv("HPAI_ASR_MODEL", "small")
    model = WhisperModel(model_name, device=os.getenv("HPAI_ASR_DEVICE", "cpu"),
                         compute_type=os.getenv("HPAI_ASR_COMPUTE_TYPE", "int8"))
    segments, info = model.transcribe(str(audio_wav), vad_filter=True, word_timestamps=False)
    segments = list(segments)
    if not segments:
        raise RuntimeError("Movie audio mein speech detect nahi hui")

    target_name = job["target_language"].split("(")[0].strip()
    target_code = LANG_CODES.get(target_name, "hi")
    update("translating_and_dubbing", f"{len(segments)} dialogue segments translate aur dub ho rahe hain...")
    final_track = AudioSegment.silent(duration=int((segments[-1].end + 1.0) * 1000), frame_rate=24000).set_channels(1)
    for index, seg in enumerate(segments):
        source_text = (seg.text or "").strip()
        if not source_text:
            continue
        translated = translate_text(source_text, target_code)
        segment_file = job_dir / f"tts-{index:06d}.mp3"
        synthesize(translated, job, segment_file)
        spoken = AudioSegment.from_file(segment_file).set_frame_rate(24000).set_channels(1)
        slot_ms = max(250, int((seg.end - seg.start) * 1000))
        # Gently speed up longer speech to fit the original timestamp window.
        if len(spoken) > slot_ms and len(spoken) / slot_ms <= 1.35:
            spoken = spoken.speedup(playback_speed=len(spoken) / slot_ms, chunk_size=80, crossfade=20)
        if len(spoken) > slot_ms:
            spoken = spoken[:slot_ms]
        position = max(0, int(seg.start * 1000))
        final_track = final_track.overlay(spoken, position=position)
        update("translating_and_dubbing", f"Hindi dubbing: {index + 1}/{len(segments)} dialogue segments")
    final_track.export(dubbed_mp3, format="mp3", bitrate="192k")
    update("completed", "Hindi dubbed audio track ready. Original movie is unchanged; play the generated audio track alongside it.")
    return dubbed_mp3
