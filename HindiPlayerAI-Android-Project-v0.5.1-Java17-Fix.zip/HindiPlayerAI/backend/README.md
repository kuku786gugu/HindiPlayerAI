# Hindi Player AI backend (alpha)

## Requirements
- Python 3.11 recommended
- FFmpeg installed and available on PATH
- A server with sufficient CPU/RAM/disk for movie audio extraction and Whisper
- A LibreTranslate-compatible translation endpoint
- Either ElevenLabs or OpenAI TTS credentials

Install and run:

```bash
pip install -r requirements.txt
# Export variables from .env.example using your hosting provider's secret manager
uvicorn main:app --host 0.0.0.0 --port 8000
```

Deploy behind HTTPS. Keep API keys in server environment variables. Do not embed them in the Android app.

## Environment variables
- `HPAI_DATA_DIR`: working directory for uploads/jobs (default `./data`)
- `HPAI_MAX_UPLOAD_BYTES`: maximum upload size in bytes (default 100 GiB; hosting limits may be lower)
- `HPAI_ASR_MODEL`: faster-whisper model name (default `small`; first run downloads weights)
- `HPAI_ASR_DEVICE`: `cpu` or `cuda`
- `HPAI_ASR_COMPUTE_TYPE`: e.g. `int8` on CPU
- `HPAI_TRANSLATION_URL`: full LibreTranslate-compatible `/translate` endpoint
- `HPAI_TRANSLATION_API_KEY`: optional translation service key
- `ELEVENLABS_API_KEY`, `ELEVENLABS_DEFAULT_VOICE_ID`: ElevenLabs credentials
- `OPENAI_API_KEY`, `OPENAI_TTS_URL`, `OPENAI_TTS_MODEL`, `OPENAI_TTS_VOICE`: OpenAI TTS configuration

## API
- `GET /health`
- `POST /jobs` multipart fields: `movie`, `target_language`, `mode=online`, `provider=elevenlabs|openai`, optional `voice_id`
- `GET /jobs/{job_id}`
- `GET /jobs/{job_id}/audio`

## Current pipeline limitations
The current pipeline extracts the movie's mixed audio, transcribes it, translates each detected speech segment, synthesizes speech with one configured voice, and places generated segments at approximate original timestamps. It returns a separate MP3 dialogue track. It does not yet separate dialogue from music/effects, preserve a clean music-only bed, identify speakers, assign character-specific voices, or mux a final MP4. Timing is approximate and can sound clipped/unnatural when translated speech does not fit the source segment.

Bhojpuri is currently mapped to Hindi (`hi`) as a fallback; quality is not guaranteed. Provider support and language quality vary. Offline mode is deliberately not advertised as working because no offline model runtime/weights are included.

The alpha job queue is process-memory based and is not safe for production restarts or multi-worker deployment. Use a durable queue/database and authentication/rate limits before public deployment.
