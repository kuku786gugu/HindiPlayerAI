package com.hindiplayer.ai

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okio.BufferedSink
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

private val Ink = Color(0xFF101114)
private val Panel = Color(0xFF1D2026)
private val Orange = Color(0xFFFF7A24)
private val http = OkHttpClient.Builder().connectTimeout(60, TimeUnit.SECONDS).readTimeout(10, TimeUnit.MINUTES).writeTimeout(0, TimeUnit.SECONDS).build()

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HindiPlayerApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HindiPlayerApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var videoName by remember { mutableStateOf("Abhi koi movie select nahi ki") }
    var status by remember { mutableStateOf("Movie select karein. Online dubbing ke liye apna backend URL dalein.") }
    var targetLanguage by remember { mutableStateOf("Hindi") }
    var backendUrl by remember { mutableStateOf("https://YOUR-SERVER-DOMAIN") }
    var provider by remember { mutableStateOf("ElevenLabs") }
    var jobId by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var dubbedFile by remember { mutableStateOf<File?>(null) }
    var languageMenu by remember { mutableStateOf(false) }
    var providerMenu by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            videoUri = uri
            videoName = uri.lastPathSegment?.substringAfterLast('/') ?: "Selected movie"
            dubbedFile = null
            status = "Movie load ho gayi. Play karein ya AI dubbing shuru karein."
            try { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
        }
    }

    val videoPlayer = remember(videoUri) {
        ExoPlayer.Builder(context).build().apply { videoUri?.let { setMediaItem(MediaItem.fromUri(it)); prepare() } }
    }
    val audioPlayer = remember { ExoPlayer.Builder(context).build() }
    DisposableEffect(videoPlayer, audioPlayer) { onDispose { videoPlayer.release(); audioPlayer.release() } }

    // Keep the generated dialogue track aligned with the movie while it plays.
    LaunchedEffect(videoUri, dubbedFile) {
        while (true) {
            val file = dubbedFile
            if (file != null && file.exists()) {
                val videoPosition = videoPlayer.currentPosition
                if (kotlin.math.abs(audioPlayer.currentPosition - videoPosition) > 700) audioPlayer.seekTo(videoPosition)
                if (videoPlayer.isPlaying && !audioPlayer.isPlaying) audioPlayer.play()
                if (!videoPlayer.isPlaying && audioPlayer.isPlaying) audioPlayer.pause()
            }
            delay(400)
        }
    }

    fun startDubbing() {
        val uri = videoUri
        if (uri == null) { status = "Pehle phone se movie select karein."; return }
        if (backendUrl.startsWith("https://YOUR-") || backendUrl.isBlank()) { status = "Pehle deployed backend ka URL dalein."; return }
        busy = true
        status = "Movie server par upload ho rahi hai. Badi file mein waqt lag sakta hai..."
        scope.launch {
            try {
                val id = withContext(Dispatchers.IO) {
                    val name = videoName.substringAfterLast('/').ifBlank { "movie.mp4" }
                    val streamBody = object : RequestBody() {
                        override fun contentType() = "application/octet-stream".toMediaType()
                        override fun contentLength() = -1L
                        override fun isOneShot() = true
                        override fun writeTo(sink: BufferedSink) {
                            context.contentResolver.openInputStream(uri)?.use { input ->
                                val buffer = ByteArray(1024 * 1024)
                                while (true) { val n = input.read(buffer); if (n < 0) break; sink.write(buffer, 0, n) }
                            } ?: throw IllegalStateException("Phone se movie read nahi ho paayi")
                        }
                    }
                    val form = MultipartBody.Builder().setType(MultipartBody.FORM)
                        .addFormDataPart("movie", name, streamBody)
                        .addFormDataPart("target_language", targetLanguage)
                        .addFormDataPart("mode", "online")
                        .addFormDataPart("provider", if (provider == "OpenAI TTS") "openai" else "elevenlabs")
                        .build()
                    val request = Request.Builder().url(backendUrl.trimEnd('/') + "/jobs").post(form).build()
                    http.newCall(request).execute().use { response ->
                        val body = response.body?.string().orEmpty()
                        if (!response.isSuccessful) throw IllegalStateException("Server error ${response.code}: $body")
                        JSONObject(body).getString("job_id")
                    }
                }
                jobId = id
                status = "Upload poora. AI ab dialogue pehchan, translation aur voice bana raha hai..."
                var completed = false
                var attempts = 0
                while (!completed && attempts < 720) {
                    attempts++
                    val result = withContext(Dispatchers.IO) {
                        val req = Request.Builder().url(backendUrl.trimEnd('/') + "/jobs/$id").get().build()
                        http.newCall(req).execute().use { r ->
                            val body = r.body?.string().orEmpty()
                            if (!r.isSuccessful) throw IllegalStateException("Status error ${r.code}: $body")
                            JSONObject(body)
                        }
                    }
                    val state = result.optString("status")
                    val message = result.optString("message", state)
                    status = message
                    if (state == "failed") throw IllegalStateException(message)
                    if (state == "completed") completed = true else delay(5000)
                }
                if (!completed) throw IllegalStateException("Processing kaafi der se chal raha hai. Job ID: $id. Baad mein dobara status check karein.")
                val file = withContext(Dispatchers.IO) {
                    val req = Request.Builder().url(backendUrl.trimEnd('/') + "/jobs/$id/audio").get().build()
                    http.newCall(req).execute().use { r ->
                        if (!r.isSuccessful) throw IllegalStateException("Audio download error ${r.code}")
                        val out = File(context.cacheDir, "hindi-dub-$id.mp3")
                        r.body?.byteStream()?.use { input -> out.outputStream().use { input.copyTo(it) } }
                        out
                    }
                }
                dubbedFile = file
                audioPlayer.setMediaItem(MediaItem.fromUri(Uri.fromFile(file)))
                audioPlayer.prepare()
                audioPlayer.seekTo(videoPlayer.currentPosition)
                if (videoPlayer.isPlaying) audioPlayer.play()
                status = "Hindi dubbed audio ready! Movie play karte waqt dubbed dialogue track sync rahega."
            } catch (e: Exception) {
                status = "Dubbing mein dikkat: ${e.message ?: "Unknown error"}"
            } finally { busy = false }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Orange, background = Ink, surface = Panel)) {
        Scaffold(containerColor = Ink) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(color = Orange, shape = RoundedCornerShape(14.dp), modifier = Modifier.size(48.dp)) { Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.PlayArrow, null, tint = Color.Black, modifier = Modifier.size(34.dp)) } }
                    Spacer(Modifier.width(12.dp)); Column {
                        Text("Hindi Player AI", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                        Text("Movies in your language 🇮🇳", color = Color.LightGray, fontSize = 12.sp)
                    }
                }
                Surface(color = Panel, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("MOVIE PLAYER", color = Orange, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        if (videoUri != null) AndroidView(factory = { ctx -> PlayerView(ctx).apply { player = videoPlayer; useController = true } }, update = { it.player = videoPlayer }, modifier = Modifier.fillMaxWidth().height(220.dp))
                        else Box(Modifier.fillMaxWidth().height(190.dp).background(Color(0xFF090A0C), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) { Text("Your movie appears here", color = Color.LightGray) }
                        Text(videoName, color = Color.White, fontWeight = FontWeight.Medium)
                        Button(onClick = { picker.launch(arrayOf("video/*")) }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Orange)) {
                            Icon(Icons.Default.FolderOpen, null, tint = Color.Black); Spacer(Modifier.width(8.dp)); Text("Phone se movie select karein", color = Color.Black)
                        }
                    }
                }
                Surface(color = Panel, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Translate, null, tint = Orange); Spacer(Modifier.width(8.dp)); Text("AI Dubbing", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp) }
                        ExposedDropdownMenuBox(expanded = languageMenu, onExpandedChange = { languageMenu = !languageMenu }) {
                            OutlinedTextField(value = targetLanguage, onValueChange = {}, readOnly = true, label = { Text("Sunne ki language") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = languageMenu) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                            ExposedDropdownMenu(expanded = languageMenu, onDismissRequest = { languageMenu = false }) {
                                listOf("Hindi", "Bhojpuri", "Bengali", "Tamil", "Telugu", "Marathi", "Punjabi", "Gujarati", "Kannada", "Malayalam", "Odia", "Assamese").forEach { lang -> DropdownMenuItem(text = { Text(lang) }, onClick = { targetLanguage = lang; languageMenu = false }) }
                            }
                        }
                        ExposedDropdownMenuBox(expanded = providerMenu, onExpandedChange = { providerMenu = !providerMenu }) {
                            OutlinedTextField(value = provider, onValueChange = {}, readOnly = true, label = { Text("Online voice provider") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = providerMenu) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                            ExposedDropdownMenu(expanded = providerMenu, onDismissRequest = { providerMenu = false }) {
                                listOf("ElevenLabs", "OpenAI TTS").forEach { item -> DropdownMenuItem(text = { Text(item) }, onClick = { provider = item; providerMenu = false }) }
                        }
                        }
                        OutlinedTextField(value = backendUrl, onValueChange = { backendUrl = it }, label = { Text("Deployed AI backend URL") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Button(onClick = { startDubbing() }, enabled = !busy, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Orange)) {
                            Text(if (busy) "AI kaam kar raha hai..." else "Movie ko Hindi mein dub karein", color = Color.Black)
                        }
                        if (busy) LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = Orange)
                        Text(status, color = Color(0xFFFFD1B5), fontSize = 12.sp)
                        jobId?.let { Text("Job ID: $it", color = Color.Gray, fontSize = 10.sp) }
                    }
                }
                Text("Note: Online AI ke liye backend server, FFmpeg, Whisper, translation service aur ElevenLabs API key chahiye. Is version mein generated dialogue MP3 alag track hai; original background music ko alag karke mix karna aur offline voice packs abhi baaki hain. Server upload limit aur phone storage/network par file size depend karega. OpenAI TTS ke liye bhi server par API key chahiye.", color = Color.Gray, fontSize = 11.sp)
            }
        }
    }
}
