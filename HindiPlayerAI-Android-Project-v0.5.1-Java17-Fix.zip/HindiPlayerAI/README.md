# Hindi Player AI — Android + AI dubbing backend (v0.5.0)

This repository contains an Android 12+ local video player prototype and a FastAPI online dubbing backend. It is an alpha development project, not a ready-to-install tested APK.

## Current capabilities
- Select and play local videos with Android Media3.
- Choose one of 12 Indian target languages.
- Upload a movie to the configured backend, poll the job, and download the generated dialogue MP3.
- Best-effort playback synchronization of the dubbed dialogue track with the movie.
- Backend adapters for ElevenLabs and OpenAI TTS, plus a LibreTranslate-compatible translation endpoint and faster-whisper speech recognition.

## Important limitations
- No built APK is included; no Android build or real-device test has yet passed in this environment.
- Online dubbing requires a deployed server, FFmpeg, translation endpoint, ASR model download, and provider API credentials.
- API keys belong on the backend only, never in the APK.
- The output is currently a separate MP3 track, not a muxed dubbed MP4. Background music/source separation, multi-speaker diarization/voice mapping, and offline voice models are not implemented.
- The selected provider and listed language do not guarantee provider coverage or natural-sounding results for every language. Bhojpuri currently uses the Hindi translation code.
- Large uploads depend on hosting limits, server disk/CPU/RAM, network, codecs and phone storage. “Unlimited GB” cannot be guaranteed.

## Build a debug APK using GitHub Actions (phone-friendly)
1. Upload this project to a GitHub repository.
2. Open the repository's **Actions** tab.
3. Select **Build Hindi Player AI APK** and press **Run workflow** (or push to `main`).
4. When the workflow finishes, open its run and download the `Hindi-Player-AI-debug-apk` artifact.
5. Extract the ZIP on your Android phone and install the debug APK. Android may ask you to allow installation from that source.

A successful CI build still does not deploy the AI backend or make the offline mode work.

## Backend setup
See [`backend/README.md`](backend/README.md) and [`backend/.env.example`](backend/.env.example). Install FFmpeg and Python requirements, configure translation/TTS credentials as environment variables, and run:

```bash
cd backend
uvicorn main:app --host 0.0.0.0 --port 8000
```

Use a public HTTPS deployment URL in the app. Do not expose API keys to the Android client.

## Project status
See [`IMPLEMENTATION_STATUS.md`](IMPLEMENTATION_STATUS.md) for implemented features and remaining work.
