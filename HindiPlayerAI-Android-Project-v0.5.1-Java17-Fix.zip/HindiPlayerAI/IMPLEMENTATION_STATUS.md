# Hindi Player AI — implementation status (v0.5.0)

## Implemented in this source project
- Android 12+ Kotlin/Jetpack Compose app shell and Media3 local video playback.
- Android document picker for local video files.
- Target language selection: Hindi, Bhojpuri, Bengali, Tamil, Telugu, Marathi, Punjabi, Gujarati, Kannada, Malayalam, Odia, Assamese.
- Online job submission from Android to the FastAPI backend using streamed request-body reads (the app does not first copy the whole movie into RAM).
- Job status polling and generated MP3 download.
- A second Media3 player track that follows the movie playback position (best-effort sync; not frame-accurate).
- Backend pipeline scaffold: FFmpeg audio extraction, faster-whisper transcription/timestamps, LibreTranslate-compatible translation, and ElevenLabs or OpenAI TTS.
- Backend upload size limit is configurable with `HPAI_MAX_UPLOAD_BYTES`.
- GitHub Actions workflow to build a debug APK artifact.

## Not implemented / not verified
- No APK has been built or device-tested in this environment. Use the included GitHub Actions workflow to attempt a build.
- No backend has been deployed and no API credentials are included.
- The app currently downloads a separate dubbed dialogue MP3; it does not produce a final dubbed MP4.
- Background music/source separation and original ambience preservation are not implemented.
- Speaker diarization, per-character voice assignment, and gender/character voice mapping are not implemented.
- Offline ASR/translation/TTS Android model packs are not bundled. The offline mode is not functional.
- OpenAI TTS language/voice quality and provider availability depend on account, model, and API support; this is not guaranteed for every listed Indian language.
- Bhojpuri currently maps to Hindi (`hi`) in the translation adapter; quality may be limited.
- No guarantee for arbitrary file sizes. Actual limits depend on server configuration, hosting quotas, disk, processing time, codecs, network, and phone storage.
- Job state is held in process memory; this alpha backend is not production-safe for multiple workers/restarts.

## Server setup
1. Install Python dependencies from `backend/requirements.txt` and install FFmpeg on the server.
2. Set environment variables from `.env.example` in the server environment (do not put API keys in the APK).
3. Set `HPAI_TRANSLATION_URL` to a trusted LibreTranslate-compatible `/translate` endpoint. Add `HPAI_TRANSLATION_API_KEY` if required.
4. For ElevenLabs set `ELEVENLABS_API_KEY` and `ELEVENLABS_DEFAULT_VOICE_ID`.
5. Or for OpenAI TTS set `OPENAI_API_KEY`, and optionally `OPENAI_TTS_MODEL` / `OPENAI_TTS_VOICE`.
6. Run `uvicorn main:app --host 0.0.0.0 --port 8000` from `backend/` behind HTTPS in production.
7. Enter the public HTTPS backend base URL in the Android app.

This is an alpha development project, not a finished consumer-ready dubbing app.
