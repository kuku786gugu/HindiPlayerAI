# Render deployment for the Android `/jobs` API

In Render, create a Docker Web Service from this project/repository with:
- Root Directory: `backend`
- Dockerfile Path: `Dockerfile`

Set these server-side environment variables in Render (never in the Android app):
- `HPAI_ASR_MODEL` = `base` (start smaller to reduce first deployment load; `small` may be more accurate but heavier)
- `HPAI_ASR_DEVICE` = `cpu`
- `HPAI_ASR_COMPUTE_TYPE` = `int8`
- `HPAI_TRANSLATION_URL` = a trusted LibreTranslate-compatible HTTPS `/translate` endpoint
- `ELEVENLABS_API_KEY` = your ElevenLabs API key
- `ELEVENLABS_DEFAULT_VOICE_ID` = your ElevenLabs voice ID
- Optional OpenAI TTS: `OPENAI_API_KEY`, `OPENAI_TTS_MODEL`, `OPENAI_TTS_VOICE`

The Android app uploads the movie to `POST /jobs`, polls `GET /jobs/{job_id}`, then downloads `GET /jobs/{job_id}/audio`.

Important: this is an alpha pipeline. It needs a reachable translation service and FFmpeg. Large videos may exceed hosting request/time/disk limits. Render free instances may sleep, run out of memory, or time out on long videos. Job state and files are ephemeral and in-memory/local-disk; this is not production-ready. The generated MP3 is a separate dialogue track, not a final muxed MP4.
